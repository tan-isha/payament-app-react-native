import { StatusBar } from "expo-status-bar";
import React from "react";
import { StyleSheet, Text, View ,Toggle,Button,Switch,ImageBackground} from "react-native";
import StripeApp from "./src/screens/StripeApp";
import { StripeProvider } from "@stripe/stripe-react-native";

import { useState } from "react";

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

function HomeScreen({ navigation }) {
   const [isEnabled, setIsEnabled] = useState(false);
  const toggleSwitch = () => setIsEnabled(previousState => !previousState);
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <ImageBackground         
         source={require('/assets/Shopin.png')}
         style={{width: '100%', height: '100%'}}>
    
 
      <Switch
      trackColor={{ false: "#767577", true: "#191E17" }}
        thumbColor={isEnabled ? "#f5dd4b" : "#f4f3f4"}
        ios_backgroundColor="#3e3e3e"
        onValueChange={toggleSwitch}
      onTouchEnd={navigation.navigate('Details')}
      
      style={{ marginTop:340, alignSelf: 'center'}}
      value={isEnabled}
      /> 
      </ImageBackground>
    </View>
  );
}

function DetailsScreen() {
  return (

  <StripeProvider publishableKey="pk_test_TYooMQauvdEDq54NiTphI7jx">
     <StripeApp />
    </StripeProvider>
    

 
  );
}

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Details" component={DetailsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
//export default function App() {

//}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
      imagebg: {
    flex: 1,
    justifyContent: "center"
  },
});
export default App;
