import React, { useState } from "react";
import { View, Text, StyleSheet, TextInput, Button, Alert ,Image,ImageBackground} from "react-native";
import { CardField, useConfirmPayment } from "@stripe/stripe-react-native";

//ADD localhost address of your server
const API_URL = "http://localhost:3000";

const StripeApp = props => {
  const [email, setEmail] = useState();
  const [cardDetails, setCardDetails] = useState();
  const { confirmPayment, loading } = useConfirmPayment();

  const fetchPaymentIntentClientSecret = async () => {
    const response = await fetch(`${API_URL}/create-payment-intent`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    });
    const { clientSecret, error } = await response.json();
    return { clientSecret, error };
  };

  const handlePayPress = async () => {
    //1.Gather the customer's billing information (e.g., email)
    if (!cardDetails?.complete || !email) {
      Alert.alert("Please enter Complete card details and personal information");
      return;
    }

    
    const billingDetails = {
      email: email,
    };
   
    //2.Fetch the intent client secret from the backend
    try {
      const { clientSecret, error } = await fetchPaymentIntentClientSecret();
      //2. confirm the payment
      if (error) {
        console.log("Unable to process payment");
      } else {
        const { paymentIntent, error } = await confirmPayment(clientSecret, {
          type: "Card",
          billingDetails: billingDetails,
        });
        if (error) {
          alert(`Payment Confirmation Error ${error.message}`);
        } else if (paymentIntent) {
          alert("Payment Successful");
          console.log("Payment successful ", paymentIntent);
        }
      }
    } catch (e) {
      console.log(e);
    }
    //3.Confirm the payment with the card details
      if ( email) {
      Alert.alert("Payment Successful");
      return;
    }
  };

  return (
    <View style={styles.container}>
     <ImageBackground         source={{
          uri: 'https://cdn.99images.com/photos/wallpapers/3d-abstract/white-aesthetic%20android-iphone-desktop-hd-backgrounds-wallpapers-1080p-4k-dmkpl.jpg',
        }} resizeMode="cover" style={styles.imagebg}>
    
     <Image
        style={styles.tinyLogo}
        source={{
          uri: 'https://www.visa.co.in/dam/VCOM/regional/ap/india/global-elements/images/in-visa-gold-card-498x280.png',
        }}
      />
        <Text style={styles.inputtext}>{"Personal Details"}</Text>
     
            <TextInput
        autoCapitalize="none"
        placeholder="Name"
        keyboardType="text"
        onChange={value => setEmail(value.nativeEvent.text)}
        style={styles.input}
      />

      <TextInput
        autoCapitalize="none"
        placeholder="E-mail"
        keyboardType="email-address"
        onChange={value => setEmail(value.nativeEvent.text)}
        style={styles.input}
      />
            <TextInput
        autoCapitalize="none"
        placeholder="Phone"
        keyboardType="text"
        onChange={value => setEmail(value.nativeEvent.text)}
        style={styles.input}
      />
            <TextInput
        autoCapitalize="none"
        placeholder="Phone"
        keyboardType="text"
        onChange={value => setEmail(value.nativeEvent.text)}
        style={styles.input}
      />
      <Text style={styles.inputtext}>{"Card Details"}</Text>
      <CardField
        postalCodeEnabled={true}
        placeholder={{
          number: "4242 4242 4242 4242",
        }}
        cardStyle={styles.card}
        style={styles.cardContainer}
        onCardChange={cardDetails => {
          setCardDetails(cardDetails);
        }}
      />
      <Button onPress={handlePayPress} title="Pay"  />
       </ImageBackground >
    </View>
  );
};
export default StripeApp;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    margin: 20,
  },
  input: {
    backgroundColor: "#efefefef",

    borderRadius: 8,
    fontSize: 20,
    height: 50,
    padding: 10,
     margin: 5,
  },
    inputtext: {


 
    fontSize: 15,
    height: 50,
    padding: 10,
     margin: 5,
  },
  card: {
    backgroundColor: "#efefefef",
  },
  cardContainer: {
    height: 50,
   
 
  },
    tinyLogo: {
  margin: 15,
  paddingBottom: 30,
   
    height: 200,
    width:330,
  },
    imagebg: {
    flex: 1,
    justifyContent: "center"
  },
});
